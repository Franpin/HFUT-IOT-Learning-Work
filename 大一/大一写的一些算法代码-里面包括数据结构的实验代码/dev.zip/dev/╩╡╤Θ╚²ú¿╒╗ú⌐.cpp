#include<iostream>
using namespace std;
class stack{
	stack(){
		
	}
	
	
};
