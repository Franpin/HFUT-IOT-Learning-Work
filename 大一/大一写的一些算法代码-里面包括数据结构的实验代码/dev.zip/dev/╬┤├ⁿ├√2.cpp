#include<iostream>
#include"ctype.h"
#include<stdlib.h>
using namespace std;
int main(){
	char str[10]="1.23";
	double d=atof(str);
	char c=' ';
	if(c=' ')
		cout<<"hello";
} 
